## TCPERPUSTAKAAN
Core Sistem Informasi Perpustakaan Berbasis Code Igniter untuk Pemula Basis HMVC

<strong>URL Login : http://localhost/tcperpustakaan</strong> <br>
User Administrator <br>
Username : admin <br>
Password : admin <br>

